Php Bounce Handler v7.3  July 4, 2013.

Replaced deprecated split() function.
Added auto-responder identification filter.  
Suppressed php Notice errors.

Instructions:
Upload to a website, and open testdriver1.php in a web browser

